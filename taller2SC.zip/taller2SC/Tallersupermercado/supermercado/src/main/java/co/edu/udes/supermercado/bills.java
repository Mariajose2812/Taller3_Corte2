/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.supermercado;

/**
 *
 * @author Maria jose
 */
public class bills {
    private String list_of_products;
    private double total_cost;
     private date date_of_purchase;
    private String payment_method;
    private String customer_information;
    private String invoice_type;
    private String employee_information;
    private int box_number;

    public void setList_of_products(String list_of_products) {
        this.list_of_products = list_of_products;
    }

    public void setTotal_cost(double total_cost) {
        this.total_cost = total_cost;
    }

    public void setDate_of_purchase(date date_of_purchase) {
        this.date_of_purchase = date_of_purchase;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public void setCustomer_information(String customer_information) {
        this.customer_information = customer_information;
    }

    public void setInvoice_type(String invoice_type) {
        this.invoice_type = invoice_type;
    }

    public void setEmployee_information(String employee_information) {
        this.employee_information = employee_information;
    }

    public void setBox_number(int box_number) {
        this.box_number = box_number;
    }
    

    public bills(String list_of_products, double total_cost, date date_of_purchase, String payment_method, String customer_information, String invoice_type, String employee_information, int box_number) {
        this.list_of_products = list_of_products;
        this.total_cost = total_cost;
        this.date_of_purchase = date_of_purchase;
        this.payment_method = payment_method;
        this.customer_information = customer_information;
        this.invoice_type = invoice_type;
        this.employee_information = employee_information;
        this.box_number = box_number;
    }

    public String getList_of_products() {
        return list_of_products;
    }

    public double getTotal_cost() {
        return total_cost;
    }

    public date getDate_of_purchase() {
        return date_of_purchase;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public String getCustomer_information() {
        return customer_information;
    }

    public String getInvoice_type() {
        return invoice_type;
    }

    public String getEmployee_information() {
        return employee_information;
    }

    public int getBox_number() {
        return box_number;
    }
    
}
