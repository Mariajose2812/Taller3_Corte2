/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.supermercado;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class supermercado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        ArrayList<employee> empleado = new ArrayList<>();
        ArrayList<customer> cliente = new ArrayList<>();

        ArrayList<producto> producto = new ArrayList<>();
System.out.println("--Menu--");

        int option = 0;

        do {
            System.out.println("1.Personas(Empleado o cliente) \n2.Producto \n3 Salir");
            option = teclado.nextInt();

            switch (option) {
                case 1:
                    
                        AddPerson(teclado,empleado,cliente);
                        break;

                case 2:
                   
                        AddProduct(teclado, producto);
                        break;
                    
               
                    
                case 3:
                    listar(empleado,cliente,producto);
            }
        } while (option <= 6);
    }
    

    public static void AddPerson(Scanner teclado, ArrayList<employee> empleado, ArrayList<customer> cliente) {
        System.out.println("--Sub menu personas--- \n");
        int option = 0;
         do {
            System.out.println("1.Empleado \n2.Cliente \n3.salir");
            option = teclado.nextInt();
            try {

            } catch (NumberFormatException e) {
                System.out.println("Ingrese una opción válida");
                continue;
            }

            switch (option) {
                case 1 -> {
                    System.out.println("Nombre del empleado: ");
                    String nombreEmpleado = teclado.next();
                    
                      System.out.println("Documento:");
                    String documento = teclado.next();
                    
                    System.out.println("Tipo de empleado:");
                    String TipodeEmpleado = teclado.next();
                    
                    System.out.println("Codigo:");
                    String codigo = teclado.next();
                                                       
                    System.out.println("Telefono:");
                    String telefono = teclado.next();

                    System.out.println("Salario del empleado:");
                    double SalarioEmpleado = teclado.nextDouble();
                                                 
                    System.out.println("Horario:");
                    String horario = teclado.next();
                    
                   
                    empleado.add(new employee(SalarioEmpleado, TipodeEmpleado, nombreEmpleado, documento,codigo,horario,telefono));
                }
                case 2 -> {
                    
                    System.out.println("Nombre del cliente");
                    String nombreCliente = teclado.next();
                    
                    System.out.println("Documento del cliente");
                    String documento = teclado.next();

                    System.out.println("Tipo de cliente:");
                    int tipodecliente = teclado.nextInt();
                    
                    System.out.println("Telefono del cliente");
                    String telefonoCliente = teclado.next();
                    
                    System.out.println("Horario:");
                    String horario = teclado.next();

                    cliente.add(new customer(telefonoCliente, documento, nombreCliente, tipodecliente , horario));

                }
            }
        } while (option <= 2);
    }

    public static void AddProduct(Scanner teclado, ArrayList<producto> producto) {
        
        System.out.println("Escriba el tipo de producto(Limpieza,Despensa,Bebidas,Cuidado personal,carnes, etc...): ");
        String tipe_product = teclado.next();
        
        System.out.println("Escriba el nombre del producto: ");
        String products = teclado.next();
        
        System.out.println("Escriba el id del producto:");
        int id = teclado.nextInt();

        
        System.out.println("Escriba el precio de los productos: ");
        double precio = teclado.nextDouble();

      
        producto.add(new producto(id,products,precio,tipe_product));
    }
    
    public static void listar( ArrayList<employee> empleado,  ArrayList<customer> cliente,  ArrayList<producto> producto){
    
    System.out.println(empleado.toString());
    System.out.println(cliente.toString());
    System.out.println(producto.toString());
    
    }
}
    
    

