/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.supermercado;

/**
 *
 * @author Maria jose
 */
public class products {
  private String name;
  private String category;
  private double price;
  private String barcode;
  private int  product_quantity;
  private  date due_date;

    public void setName(String name) {
        this.name = name;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setProduct_quantity(int product_quantity) {
        this.product_quantity = product_quantity;
    }

    public void setDue_date(date due_date) {
        this.due_date = due_date;
    }

    
    
    
    
    public String getName() {
        return name;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    public String getBarcode() {
        return barcode;
    }

    public int getProduct_quantity() {
        return product_quantity;
    }

    public date getDue_date() {
        return due_date;
    }

    public products(String name, String category, double price, String barcode, int product_quantity, date due_date) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.barcode = barcode;
        this.product_quantity = product_quantity;
        this.due_date = due_date;
    }
}
