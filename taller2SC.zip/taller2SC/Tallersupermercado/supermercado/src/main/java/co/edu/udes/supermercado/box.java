/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.supermercado;

/**
 *
 * @author Maria jose
 */
public class box {
    private int box_number;
    private String name_of_the_employee;
    private String type_of_box;
    private String payment_method;

    public void setBox_number(int box_number) {
        this.box_number = box_number;
    }

    public void setName_of_the_employee(String name_of_the_employee) {
        this.name_of_the_employee = name_of_the_employee;
    }

    public void setType_of_box(String type_of_box) {
        this.type_of_box = type_of_box;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    
    
    
    public int getBox_number() {
        return box_number;
    }

    public String getName_of_the_employee() {
        return name_of_the_employee;
    }

    public String getType_of_box() {
        return type_of_box;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public box(int box_number, String name_of_the_employee, String type_of_box, String payment_method) {
        this.box_number = box_number;
        this.name_of_the_employee = name_of_the_employee;
        this.type_of_box = type_of_box;
        this.payment_method = payment_method;
    }
}
