/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.tallercine;

/**
 *
 * @author Maria jose
 */
public class food {
   private String kind_of_food;
  private String kind_of_drink;
  private String payment_method;
  private double price;

    public void setKind_of_food(String kind_of_food) {
        this.kind_of_food = kind_of_food;
    }

    public void setKind_of_drink(String kind_of_drink) {
        this.kind_of_drink = kind_of_drink;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    

    public String getKind_of_food() {
        return kind_of_food;
    }

    public String getKind_of_drink() {
        return kind_of_drink;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public double getPrice() {
        return price;
    }

    public food(java.lang.Double price, String kind_of_food, String kind_of_drink, String payment_method) {
        this.kind_of_food = kind_of_food;
        this.kind_of_drink = kind_of_drink;
        this.payment_method = payment_method;
        this.price = price;
    }
    @Override
    public String toString() {
        return "meal{" + "kind_of_food=" + kind_of_food + ", kind_of_drink=" + kind_of_drink + ", payment_method=" + payment_method + ",price =" + price + '}';
    }
}
 

