/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.tallercine;

/**
 *
 * @author Maria jose
 */
public class Customer {
    private String name;
    private String document;
    private String customer_type;
    private int phone;
    private int age;

    Customer(String name, String document, String phone, String customer_type, String age) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public void setCustomer_type(String customer_type) {
        this.customer_type = customer_type;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public void setAge(int age) {
        this.age = age;
    }
 

    public Customer(String name, String document, String customer_type, int phone, int age) {
        this.name = name;
        this.document = document;
        this.customer_type = customer_type;
        this.phone = phone;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public String getDocument() {
        return document;
    }

    public String getCustomer_type() {
        return customer_type;
    }

    public int getPhone() {
        return phone;
    }

    public int getAge() {
        return age;
    }
    
    @Override
    public String toString() {
        return "customer{" + "name=" + name+ ", document=" + document+ ", customer_type=" + customer_type + ", phone=" + phone + ", age=" +age +'}';
    }
}
