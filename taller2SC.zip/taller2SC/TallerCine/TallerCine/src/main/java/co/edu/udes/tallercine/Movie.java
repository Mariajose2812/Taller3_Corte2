/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.tallercine;

import java.util.Date;

/**
 *
 * @author Maria jose
 */
public class Movie {
      private String gender;
    private double duration;
    private String schedule;
    private int age_range;
    private String synopsis;
    
    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setDuration(double duration) {
        this.duration = duration;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public void setAge_range(int age_range) {
        this.age_range = age_range;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    

    public void setKind_of_movie(String kind_of_movie) {
        this.kind_of_movie = kind_of_movie;
    }
    private String kind_of_movie;

    public Movie(String gender, String schedule, String synopsis, String kind_of_movie, String gender1) {
        this.gender = gender;
        this.duration = duration;
        this.schedule = schedule;
        this.age_range = age_range;
        this.synopsis = synopsis;
       
        this.kind_of_movie = kind_of_movie;
    }

    public String getGender() {
        return gender;
    }

    public double getDuration() {
        return duration;
    }

    public String getSchedule() {
        return schedule;
    }

    public int getAge_range() {
        return age_range;
    }

    public String getSynopsis() {
        return synopsis;
    }

   

    public String getKind_of_movie() {
        return kind_of_movie;
    }
    @Override
    public String toString() {
        return "movie{" + "gender=" + gender + ",duration=" + duration + ", schedule=" + schedule + ", age_range=" + age_range +",synopsis="+ synopsis + '}';
    }
}
